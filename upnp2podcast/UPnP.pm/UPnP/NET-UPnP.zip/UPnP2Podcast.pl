##    UPnP2Podcast.pl - Display UPnP servers as podcasts
##    Copyright (C) 2009    Scott Zadigian  zadigian(at)gmail
##
##    This program is free software; you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation; either version 2 of the License, or
##    (at your option) any later version.
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with this program; if not, write to the Free Software
##    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
##    02111-1307, USA
##---------------------------------------------------------------------------##
#! /user/bin/perl
#
##### Import libraries
    use Net::UPnP::ControlPoint;
    use Net::UPnP::AV::MediaServer;
    
    
$feed_begin = <<'FEED_BEGIN';
<rss version="2.0" xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"
  xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel> 
    <title>%%FEED_TITLE%%</title> 
    <description>%%FEED_DESCRIPTION%%</description> 
    <language>en-us</language> 
    <itunes:summary>%%FEED_DESCRIPTION%%</itunes:summary> 
    <itunes:subtitle>%%FEED_DESCRIPTION%%</itunes:subtitle> 
FEED_BEGIN
#		<link>%%FEED LINK%%</link> 
#		<language>en-us</language> 
#		<image> 
#			<title>%%FEED_IMAGE%%</title> 
#			<url>%%FEED_IMAGE_URL%%</url> 
#		</image> 
#		<pubDate>%%FEED_DATE%%</pubDate>

$item = <<'PODCAST_ITEM';
    <item> 
      <title>%%ITEM_TITLE%%</title> 
      <description>%%ITEM_DESCRIPTION%%</description> 
      <pubDate>%%ITEM_DATE%%</pubDate> 
      <itunes:subtitle>%%ITEM_DESCRIPTION%%</itunes:subtitle>
      <itunes:duration>%%ITEM_DUR%%</itunes:duration>
      <enclosure url="%%ITEM_URL%%" length="%%ITEM_SIZE%%" type="video/mpeg2" /> 
      <media:content duration="%%ITEM_DUR_SEC%%" medium="video" fileSize="%%ITEM_SIZE%%" url="%%ITEM_URL%%" type="video/mpeg2"> 
       <media:title>%%ITEM_TITLE%%</media:title> 
        <media:description>%%ITEM_DESCRIPTION%%</media:description> 
        <media:thumbnail url="%%ITEM_PICTURE%%"/> 
      </media:content> 
    </item> 
PODCAST_ITEM
#      <media:content duration="%%ITEM_DUR_SEC%%" medium="video" fileSize="%%ITEM_SIZE%%" url="%%ITEM_URL%%" type="video/mpeg2"> 
#       <media:title>%%ITEM_TITLE%%</media:title> 
#        <media:description>%%ITEM_DESCRIPTION%%</media:description> 
#        <media:thumbnail url="%%ITEM_PICTURE%%"/> 
#      </media:content> 

$feed_end = <<'FEED_END';
  </channel> 
</rss> 
FEED_END


    # Get the directory the script is being called from
    $executable = $0;
    $executable =~ m#(\\|\/)(([^\\/]*)\.([a-zA-Z0-9]{2,}))$#;;
    $executablePath = $`;
    $executableEXE  = $3; 

    # Code version
    $codeVersion = "$executableEXE v1.0beta";
    
    $invalidMsg .= "\n$codeVersion\n";
    $invalidMsg .= "\tUSAGE:";
    $invalidMsg .= "\t$executableEXE.exe (UPnP Search String)\n\n";
    
    # Move arguments into user array so we can modify it
    my @parameters = @ARGV;
    if (@parameters > 2 || @parameters < 1)
    {
        print $invalidMsg;
        exit;
    }
    
    if ($parameters[1])
    {
        $printDebugLog = 1;
    }
    
    $string = $parameters[0]; 
    @splitString = split(":",$string);   

    my $obj = Net::UPnP::ControlPoint->new();
    my $mediaServer = Net::UPnP::AV::MediaServer->new();


    
    $debugLog .= "<!--\nDebug Log:\n";
    
    my @dev_list = $obj->search();
    my %contents = {};
    $lookingFor = shift(@splitString);
    $foundDevice = 0;
    foreach (@dev_list)
    {
        chomp;
        $debugLog .= "Device: ".$_->getfriendlyname()."(".$_->getdevicetype().")\n";
        if ($_->getfriendlyname() =~ /$lookingFor/i)
        {
            $mediaServer->setdevice($_);
            $foundDevice = 1;
            $debugLog .= " * Found $lookingFor\n"; 
        }
    }
    
    if (!$foundDevice)
    {
        print "Error! Couldn't find UPnP Device: ($lookingFor)\n";
        exit;
    }
    
    #my @content_list = $mediaServer->getcontentlist(ObjectID => 0);
    #foreach $content (@content_list) 
    #{
    #    $contents{$content->gettitle()} = $content->getid();
    #    print " + Adding ".$content->gettitle()." : (".$content->getid().")\n";
    #}
    
    my $id    = 0;
    my $newId = 0;
    my $lastContent = 0;
    my $depth  = 0;
    my $filter = "";
    while (@splitString)
    {
        $lookingFor = shift(@splitString); 
        my @content_list = $mediaServer->getcontentlist(ObjectID => $id);  
        if ($lookingFor =~ /\+([0-9]+)/)
        {
            $depth = $1;
            if (@splitString)
            {
                $filter = shift(@splitString);
            }
            #print "depth : ($depth)\n";
            #print "filter: ($filter)\n";
            next;
        }
        $debugLog .= "  + Looking For: $lookingFor\n"; 
        foreach $content (@content_list) 
        {
            if ($content->gettitle() =~ /$lookingFor/)
            {
                $debugLog .= "    - Found: ".$content->gettitle()." ($lookingFor)(".$content->getid().")\n";
                $newId = $content->getid();
                $lastContent = $content;
            }
        }
        if ($newId eq $id)
        {
            print "    - Fail! ($lookingFor)\n";
            exit;
        }
        else
        {
            $id = $newId;
        }
    }
    $opening = $feed_begin;
    $title = $lastContent->gettitle();
    $opening =~ s/%%FEED_TITLE%%/$title/sg;
    $opening =~ s/%%FEED_DESCRIPTION%%/$title/sg;
    $podcastFeed = "";
    $podcastFeed .= $opening;
    @podcastItems = ();

    
    $debugLog .= "  + We're Free! ($depth)($filter)\n";
    print_content($mediaServer, $lastContent, 1, $depth);
    $debugLog .= "-->\n\n";
    
    while(@podcastItems)
    {   # Print out items in reverse
        $podcastFeed .= pop(@podcastItems);
    }
    
    if ($printDebugLog)
    {   # Put in the debug log if nessisary
        $podcastFeed .= $debugLog;
    }  
    $podcastFeed .= $feed_end;

    print $podcastFeed;
 
     sub addItem {
        my ($content) = @_;
        my $id    = $content->getid();
        my $title = $content->gettitle();
        my $url   = $content->geturl();
        my $size  = $content->getSize();
        my $date  = $content->getdate();
        my $rating      = $content->getRating();
        my $userRating  = $content->getUserRating();
        my $dur  = $content->getDur();
        my $screenShot  = $content->getPicture();
        my $desc = $content->getDesc();
        my $newItem = $item;

        if ($title =~ /s([0-9]+)e([0-9]+): (.*)/)
        {
            my $season  = $1;
            my $episode = $2;
            my $episodeTitle = $3;
            $newItem =~ s/%%ITEM_DESCRIPTION%%/Season $season Episode $episode - $desc/sg; 
            $newItem =~ s/%%ITEM_TITLE%%/$episodeTitle/sg;
        }
        else
        {
            $newItem =~ s/%%ITEM_DESCRIPTION%%/$desc/sg;
            $newItem =~ s/%%ITEM_TITLE%%/$title/sg;     
        }
        
        $dur    =~ /([0-9]+):([0-9]+):([0-9]+).([0-9]+)/;
        my $durSec = $1*60*60 + $2*60 + $3;
        my $durMod = "$1:$2:$3";
        
        $newItem =~ s/%%ITEM_URL%%/$url/sg;
        $newItem =~ s/%%ITEM_SIZE%%/$size/sg;
        $newItem =~ s/%%ITEM_DATE%%/$date/sg;
        $newItem =~ s/%%ITEM_PICTURE%%/$screenShot/sg;
        $newItem =~ s/%%ITEM_DUR_SEC%%/$durSec/sg;
        $newItem =~ s/%%ITEM_DUR%%/$durMod/sg;
                        
        push(@podcastItems,$newItem);
    }
    
    
    sub print_content {
        my ($mediaServer, $content, $indent, $depth) = @_;
        my $id = $content->getid();
        my $title = $content->gettitle();
        
        if ($depth == 0)
        {
            return;
        }

        for ($n=0; $n<$indent; $n++) {
            $debugLog .= "\t";
        }
        $debugLog .= " + $id = $title";
        if ($content->isitem()) {
            $debugLog .= " (" . $content->geturl();
            if (length($content->getdate())) {
                $debugLog .= " - " . $content->getdate();
            }
            $debugLog .= " - " . $content->getcontenttype() . ")";
            if ($title =~ /$filter/ || $filter eq "")
            {
                addItem($content);
            }
        }
        $debugLog .= "\n";
        $depth--;
        
        unless ($content->iscontainer()) {
            return;
        }

        my @child_content_list = $mediaServer->getcontentlist(ObjectID => $id );
        if (@child_content_list <= 0) {
            return;
        }
        $indent++;
        foreach my $child_content (@child_content_list) {
            print_content($mediaServer, $child_content, $indent,$depth);
        }
    }
    